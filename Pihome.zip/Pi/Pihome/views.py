from django.shortcuts import render,HttpResponse
from django.views.decorators.csrf import csrf_exempt
io={}
import RPi.GPIO as GPIO    # Import Raspberry Pi GPIO library
from time import sleep     # Import the sleep function from the time module

GPIO.setwarnings(False)    # Ignore warning for now
GPIO.setmode(GPIO.BOARD)   # Use physical pin numbering
GPIO.setup(11, GPIO.OUT, initial=GPIO.LOW)   # Set pin 8 to be an output pin and set initial value to low (off)
GPIO.setup(13, GPIO.OUT, initial=GPIO.LOW)   
GPIO.setup(15, GPIO.OUT, initial=GPIO.LOW)   # 
GPIO.setup(16, GPIO.OUT, initial=GPIO.LOW)   # 
pins=[11,13,15,16]
import Adafruit_DHT
sensor = Adafruit_DHT.DHT11
pin = 4
data={"Sensor1":27,"Sensor2":20}
humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
xx='{0:0.1f}*C'.format(temperature)
yy='{0:0.1f}%'.format(humidity)
# Create your views here.
data['Sensor1']=xx
data['Sensor2']=yy
def Home(request):
    return render(request,"Home.html",data)
def Ajax(request):
    humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
    xx='{0:0.1f}*C'.format(temperature)
    yy='{0:0.1f}%'.format(humidity)
    # Create your views here.
    data['Sensor1']=xx
    data['Sensor2']=yy
    #Sensor Value Update
    return HttpResponse(str(data["Sensor1"])+","+str(data["Sensor2"]))
@csrf_exempt
def Update(request):
    #Sensor Value Update
    var=list(dict(request.POST)['datax[]'])
    for x in range(len(var)):
        if var[x]=='1':
            GPIO.output(pins[x], GPIO.HIGH)
        elif var[x]=='0':
            GPIO.output(pins[x], GPIO.LOW)
    return HttpResponse("Done!")
